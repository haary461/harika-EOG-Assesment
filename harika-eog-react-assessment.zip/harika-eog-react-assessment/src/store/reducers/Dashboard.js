import * as actions from "../dashboard.actions";

const initialState = {
  loading: false,
  timestamp: "",
  metric: "",
  latitude: null,
  longitude: null,
  data: {}
};

const startLoading = (state, action) => {
  return { ...state, loading: true };
};

const dashboardDataRecevied = (state, action) => {
  const { data } = action;
  if (!data["data"]) return state;
  const dashboardObj = data.data[0];
  const { timestamp, metric, latitude, longitude } = dashboardObj;
 
  return {
    ...state,
    loading: false,
    timestamp,
    metric,
    latitude,
    longitude,
    data: action.data
  };
};

const handlers = {
  [actions.FETCH_DASHBOARD]: startLoading,
  [actions.DASHBOARD_DATA_RECEIVED]: dashboardDataRecevied
};

export default (state = initialState, action) => {
  const handler = handlers[action.type];
  if (typeof handler === "undefined") return state;
  return handler(state, action);
};
