import WeatherSagas from "./Weather";
import ApiErrors from "./ApiErrors";
import DashboardSagas from "./Dashboard";
export default [...ApiErrors, ...WeatherSagas, ...DashboardSagas];
