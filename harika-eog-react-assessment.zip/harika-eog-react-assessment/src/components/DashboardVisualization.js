import React, { Component } from "react";
import Card from "@material-ui/core/Card";
import CardHeaderRaw from "@material-ui/core/CardHeader";
import CardContent from "@material-ui/core/CardContent";
import { withStyles } from "@material-ui/core/styles";
import { connect } from "react-redux";
import * as actions from "../store/dashboard.actions";

const cardStyles = theme => ({
  root: {
    background: theme.palette.primary.main,
  },
  title: {
    color: "white"
  }
});
const CardHeader = withStyles(cardStyles)(CardHeaderRaw);

const styles = {
  card: {
    margin: "5% 25%",
    fontFamily: "sans-serif"
  },
  table: {
    width: "100%"
  },
  td: {
    padding: "8px"
  }
};

class DashboardVisualization extends Component {
  componentDidMount() {
    this.props.onLoad();
    this.interval = setInterval(() => {
      this.props.onLoad();
    }, 4000);
  }

  componentWillUnmount() {
    clearInterval(this.interval);
  }

  render() {
    const {
      classes,
      timestamp,
      metric,
      latitude,
      longitude
    } = this.props;
    return (
      <Card className={classes.card}>
        <CardHeader title="Dashboard Visualization" />
        <CardContent>
          <table className={classes.table}>
            <tbody>
              <tr>
                <td className={classes.td}>Temperature:</td>
                <td className={classes.td}>{metric}</td>
              </tr>
              <tr>
                <td className={classes.td}>Latitude:</td>
                <td className={classes.td}>{latitude}</td>
              </tr>
              <tr>
                <td className={classes.td}>Longitude:</td>
                <td className={classes.td}>{longitude}</td>
              </tr>
              <tr>
                <td className={classes.td}>Last Received:</td>
                <td className={classes.td}>
                  {Math.round((new Date().getTime() - timestamp) / 1000 / 1000)}
                  &nbsp;seconds ago
                </td>
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>
    );
  }
}

const mapState = (state, ownProps) => {
  const { loading, timestamp, metric, latitude, longitude } = state.dashboard;
  return {
    loading,
    timestamp,
    metric,
    latitude,
    longitude
  };
};

const mapDispatch = dispatch => ({
  onLoad: () =>
    dispatch({
      type: actions.FETCH_DASHBOARD
    })
});

export default withStyles(styles)(
  connect(
    mapState,
    mapDispatch
  )(DashboardVisualization)
);
