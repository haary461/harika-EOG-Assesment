import React from "react";
import Typography from "@material-ui/core/Typography";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";
// import Weather from "./Weather";

const styles = {
  menuLink: {
    margin: "0 16px"
  }
};

const Header = props => {
  const { classes } = props;

  const name = "harika's";
  return (
    <AppBar position="static">
      <Toolbar>
        <Typography variant="h6" color="inherit">
          {name} EOG React Visualization Assessment
        </Typography>
        {/* <Weather /> */}
        <Button className={classes.menuLink} href='/' variant="contained" color="secondary">Dashboard</Button>
        <Button className={classes.menuLink} href="/chart" variant="contained" color="secondary">Chart </Button>
      </Toolbar>
    </AppBar>
  );
};

export default withStyles(styles)(Header);
